import { Wallet } from "ethers";
import { sha256 } from "@noble/hashes/sha2";
import { ed25519, x25519 } from "@noble/curves/ed25519";
import { adHash } from "./crypto";
import {
  generateKeyPair,
  initializeInitiator,
  initializeResponder,
  ratchetDecrypt,
  ratchetEncrypt
} from "./double_ratchet";
import {
  deriveSharedSecretInitiator,
  deriveSharedSecretResponder,
  generateOneTimePreKey,
  generateSignedPreKey,
  verifySignedPreKey
} from "./x3dh";

function equalBytes(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i += 1) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

function concatBytes(...items: Uint8Array[]): Uint8Array {
  const total = items.reduce((sum, item) => sum + item.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const item of items) {
    out.set(item, offset);
    offset += item.length;
  }
  return out;
}

function deriveIdentityKeysFromEthers(wallet: { privateKey: string }) {
  const seed = Buffer.from(wallet.privateKey.slice(2), "hex");
  const dhSeed = sha256(concatBytes(seed, new TextEncoder().encode("dh")));
  const signSeed = sha256(concatBytes(seed, new TextEncoder().encode("sign")));
  const dhPriv = dhSeed;
  const dhPub = x25519.getPublicKey(dhPriv);
  const signPriv = signSeed;
  const signPub = ed25519.getPublicKey(signPriv);
  return {
    dh: { privateKey: dhPriv, publicKey: dhPub },
    sign: { privateKey: signPriv, publicKey: signPub }
  };
}

// --- X3DH + Double Ratchet 테스트 ---
const ad = adHash(
  1n, // sessionId
  "0x0000000000000000000000000000000000000001", // rider
  "0x0000000000000000000000000000000000000002", // driver
  1n // chainId
);

// Bob publishes a bundle (IK, SPK, signature)
const bobWallet = process.env.BOB_PRIVKEY ? new Wallet(process.env.BOB_PRIVKEY) : Wallet.createRandom();
const bob = deriveIdentityKeysFromEthers(bobWallet);
const bobSpk = generateSignedPreKey(bob.sign.privateKey);
const bobOtpk = generateOneTimePreKey();

const bundle = {
  identityDhPub: bob.dh.publicKey,
  identitySignPub: bob.sign.publicKey,
  signedPreKeyPub: bobSpk.keyPair.publicKey,
  signature: bobSpk.signature,
  oneTimePreKeyPub: bobOtpk.publicKey
};

if (!verifySignedPreKey(bundle)) {
  throw new Error("X3DH signed prekey verification failed");
}

// Alice creates her identity keys + ephemeral
const aliceWallet = process.env.ALICE_PRIVKEY ? new Wallet(process.env.ALICE_PRIVKEY) : Wallet.createRandom();
const alice = deriveIdentityKeysFromEthers(aliceWallet);
const aliceEphemeral = generateKeyPair();

// X3DH shared secret (initiator/responder must match)
const sharedInitiator = deriveSharedSecretInitiator(
  alice.dh.privateKey,
  aliceEphemeral.privateKey,
  bundle
);
const sharedResponder = deriveSharedSecretResponder(
  bob.dh.privateKey,
  bobSpk.keyPair.privateKey,
  alice.dh.publicKey,
  aliceEphemeral.publicKey,
  bobOtpk.privateKey
);

console.log("sharedInitiator", sharedInitiator);
console.log("sharedResponder", sharedResponder);

if (!equalBytes(sharedInitiator, sharedResponder)) {
  throw new Error("X3DH shared secrets do not match");
}

// Initialize double ratchet from shared secret
const aliceState = initializeInitiator(sharedInitiator, bobSpk.keyPair.publicKey);
const bobState = initializeResponder(sharedResponder, bobSpk.keyPair, aliceState.dhPair.publicKey);

const encoder = new TextEncoder();
const decoder = new TextDecoder();

const msg1 = encoder.encode("message 1");
const msg2 = encoder.encode("message 2");

const packet1 = ratchetEncrypt(aliceState, msg1, ad);
const packet2 = ratchetEncrypt(aliceState, msg2, ad);
const packet3 = ratchetEncrypt(aliceState, encoder.encode("message 3"), ad);

const plaintext3 = ratchetDecrypt(bobState, packet3.header, packet3.ciphertext, ad);
console.log("Bob 수신 3:", decoder.decode(plaintext3));
const plaintext2 = ratchetDecrypt(bobState, packet2.header, packet2.ciphertext, ad);
console.log("Bob 수신 2:", decoder.decode(plaintext2));
const plaintext1 = ratchetDecrypt(bobState, packet1.header, packet1.ciphertext, ad);
console.log("Bob 수신 1:", decoder.decode(plaintext1));

const reply = encoder.encode("reply from bob");
const replyPacket = ratchetEncrypt(bobState, reply, ad);
const replyPlain = ratchetDecrypt(aliceState, replyPacket.header, replyPacket.ciphertext, ad);
console.log("Alice 수신:", decoder.decode(replyPlain));
