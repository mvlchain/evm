import { hkdf } from "@noble/hashes/hkdf";
import { sha256 } from "@noble/hashes/sha2";
import { ed25519, x25519 } from "@noble/curves/ed25519";

const INFO_X3DH = new TextEncoder().encode("X3DH");

export type IdentityKeys = {
  dh: { privateKey: Uint8Array; publicKey: Uint8Array };
  sign: { privateKey: Uint8Array; publicKey: Uint8Array };
};

export type SignedPreKey = {
  keyPair: { privateKey: Uint8Array; publicKey: Uint8Array };
  signature: Uint8Array;
};

export type OneTimePreKey = {
  privateKey: Uint8Array;
  publicKey: Uint8Array;
};

export type X3DHBundle = {
  identityDhPub: Uint8Array;
  identitySignPub: Uint8Array;
  signedPreKeyPub: Uint8Array;
  signature: Uint8Array;
  oneTimePreKeyPub?: Uint8Array;
};

export function generateIdentityKeys(): IdentityKeys {
  const dhPriv = x25519.utils.randomPrivateKey();
  const dhPub = x25519.getPublicKey(dhPriv);
  const signPriv = ed25519.utils.randomPrivateKey();
  const signPub = ed25519.getPublicKey(signPriv);
  return {
    dh: { privateKey: dhPriv, publicKey: dhPub },
    sign: { privateKey: signPriv, publicKey: signPub }
  };
}

export function generateSignedPreKey(identitySignPriv: Uint8Array): SignedPreKey {
  const spkPriv = x25519.utils.randomPrivateKey();
  const spkPub = x25519.getPublicKey(spkPriv);
  const signature = ed25519.sign(spkPub, identitySignPriv);
  return { keyPair: { privateKey: spkPriv, publicKey: spkPub }, signature };
}

export function generateOneTimePreKey(): OneTimePreKey {
  const priv = x25519.utils.randomPrivateKey();
  const pub = x25519.getPublicKey(priv);
  return { privateKey: priv, publicKey: pub };
}

export function verifySignedPreKey(bundle: X3DHBundle): boolean {
  return ed25519.verify(bundle.signature, bundle.signedPreKeyPub, bundle.identitySignPub);
}

export function deriveSharedSecretInitiator(
  identityDhPrivA: Uint8Array,
  ephemeralPrivA: Uint8Array,
  bundleB: X3DHBundle
): Uint8Array {
  const dh1 = x25519.getSharedSecret(identityDhPrivA, bundleB.signedPreKeyPub);
  const dh2 = x25519.getSharedSecret(ephemeralPrivA, bundleB.identityDhPub);
  const dh3 = x25519.getSharedSecret(ephemeralPrivA, bundleB.signedPreKeyPub);
  const ikm = bundleB.oneTimePreKeyPub
    ? concatBytes(dh1, dh2, dh3, x25519.getSharedSecret(ephemeralPrivA, bundleB.oneTimePreKeyPub))
    : concatBytes(dh1, dh2, dh3);
  return hkdf(sha256, ikm, undefined, INFO_X3DH, 32);
}

export function deriveSharedSecretResponder(
  identityDhPrivB: Uint8Array,
  signedPreKeyPrivB: Uint8Array,
  identityDhPubA: Uint8Array,
  ephemeralPubA: Uint8Array,
  oneTimePreKeyPrivB?: Uint8Array
): Uint8Array {
  const dh1 = x25519.getSharedSecret(signedPreKeyPrivB, identityDhPubA);
  const dh2 = x25519.getSharedSecret(identityDhPrivB, ephemeralPubA);
  const dh3 = x25519.getSharedSecret(signedPreKeyPrivB, ephemeralPubA);
  const ikm = oneTimePreKeyPrivB
    ? concatBytes(dh1, dh2, dh3, x25519.getSharedSecret(oneTimePreKeyPrivB, ephemeralPubA))
    : concatBytes(dh1, dh2, dh3);
  return hkdf(sha256, ikm, undefined, INFO_X3DH, 32);
}

function concatBytes(...items: Uint8Array[]): Uint8Array {
  const total = items.reduce((sum, item) => sum + item.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const item of items) {
    out.set(item, offset);
    offset += item.length;
  }
  return out;
}
